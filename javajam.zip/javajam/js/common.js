$(document).ready(function () {
    $("#mugClub").mouseover(function() {
        alert("JavaJam Mug Club Members get a 10% discount on each cup of coffee!")
    });
});